function mode = nc_nowrite_mode()
% NC_NOWRITE_MODE:  returns integer mnemonic for NC_NOWRITE
%
% USAGE:  mode = nc_nowrite_mode;
mode = 0;
return


