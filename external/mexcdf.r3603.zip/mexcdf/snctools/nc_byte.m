function nc_datatype = nc_byte()
% NC_BYTE:  returns constant corresponding to NC_BYTE enumerated constant in netcdf.h
%
% USAGE:  nc_datatype = nc_byte;
%

nc_datatype = 1;
return




